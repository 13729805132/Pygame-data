ACHIEVEMENTS = {
"money_murderer" : ["Money Murderer", "You have destroyed 50 money bags", -500],
"archer" : ["Archer", "You achieved 70% accuracy!", 17500],
"combo5" : ["Combo 5", "You shot 5 aliens in a row!", 2500],
"combo10" : ["Combo 10", "You shot 10 aliens in a row!", 5000],
"combo15" : ["Combo 15", "You shot 15 aliens in a row!", 10000],
"combo20" : ["Combo 20", "You shot 20 aliens in a row!", 20000],
"im_back" : ["I'm Back", "You collect a heart while dying!", 10000],
}
