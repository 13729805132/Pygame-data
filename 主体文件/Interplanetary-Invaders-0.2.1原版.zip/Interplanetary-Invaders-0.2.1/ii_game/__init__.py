"""Interplanetary Invaders"""
__myname__ = "Interplanetary Invaders"
__title__ = "Interplanetary Invaders"
__author__ = "NachoMonkey"
__version__ = "0.2.1"
__minimum_version__ = (3, 7)
__maximum_version__ = (3, 9)
